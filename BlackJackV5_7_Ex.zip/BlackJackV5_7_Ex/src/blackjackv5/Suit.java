package blackjackv5;

/**
 *
 * @author 
 */
public enum Suit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES
}
